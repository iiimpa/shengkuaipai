namespace WebApi.Helpers
{
    public enum Platform
    {
        Baidu,
        Sogou,
        Pc360,
        MBaidu,
        MSogou,
        M360
    }
}