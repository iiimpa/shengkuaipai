﻿using System;
namespace WebApi.Models
{
    public class ClickPlan
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int UserId { get; set; }
        public int T0 { get; set; }
        public int T1 { get; set; }
        public int T2 { get; set; }
        public int T3 { get; set; }
        public int T4 { get; set; }
        public int T5 { get; set; }
        public int T6 { get; set; }
        public int T7 { get; set; }
        public int T8 { get; set; }
        public int T9 { get; set; }
        public int T10 { get; set; }
        public int T11 { get; set; }
        public int T12 { get; set; }
        public int T13 { get; set; }
        public int T14 { get; set; }
        public int T15 { get; set; }
        public int T16 { get; set; }
        public int T17 { get; set; }
        public int T18 { get; set; }
        public int T19 { get; set; }
        public int T20 { get; set; }
        public int T21 { get; set; }
        public int T22 { get; set; }
        public int T23 { get; set; }
        public DateTime UpdatedAt { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
