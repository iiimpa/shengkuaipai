import requests


def get_proxy():
    url = "http://webapi.http.zhimacangku.com/getip?num=1&type=2&pro=&city=0&yys=0&port=1&time=1&ts=1&ys=1&cs=1&lb=1&sb=0&pb=45&mr=1&regions="
    response = requests.get(url)
    jobj = response.json()
    print(jobj)
    if jobj['success']:
        return "%s:%d" % (jobj['data'][0]['ip'], jobj['data'][0]['port'])
    else:
        return False
