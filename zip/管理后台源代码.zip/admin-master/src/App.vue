<template>
    <div id="app">
        <router-view></router-view>
    </div>
</template>

<style>
    html, body, p, body, #app {
        margin: 0;
        box-sizing: border-box;
        padding: 0;
    }
</style>
